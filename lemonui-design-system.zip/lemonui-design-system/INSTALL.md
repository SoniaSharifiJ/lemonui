# Install or update

Extract `lemonui-design-system.zip` and place the included `lemonui-design-system` folder in `$CODEX_HOME/skills/` (usually `~/.codex/skills/`). Preserve a copy of any customized existing version before replacing it. Start a new Codex chat to load the updated instructions.

Invoke `$lemonui-design-system` for a relevant UI task. Supply a brand palette or an existing project theme; the skill reuses this information and saves project-scoped tokens instead of asking on every edit.

The package contains the reusable skill and a neutral starter token file. It does not include this conversation's ERP prototype, brand, screenshots, private data, or GitHub credentials. It does not install a framework or publish a site.
