---
name: lemonui-design-system
description: Create, refine, or review Persian RTL product interfaces against Lemon's documented design foundations and component patterns, with project-specific branding, frosted surfaces, Vazirmatn typography, and consistent interaction states. Use when Lemon UI is requested or already adopted by the project.
---

# Lemon UI Design System

Use [Lemon's public source](https://lemonui.ir/) and the documented baseline in [lemon-reference.md](references/lemon-reference.md). Lemon is an RTL-first Figma system, not an installable frontend component package. Match documented anatomy and tokens; describe newly derived values as project adaptations. Do not claim exact visual fidelity without inspecting the relevant source sample and the rendered result.

## Adopt the project theme once

On first UI use in a project, ask: "What brand colors, palette, or existing color system should this project use? You can share color values, brand guidelines, existing theme tokens, or a reference, or say you have none."

If the current project already supplies that information, use it without asking again. Otherwise wait for the answer before choosing the first theme; unrelated preparation can continue. If the user has no system, propose a suitable palette and proceed unless they request approval first.

Follow [token-workflow.md](references/token-workflow.md). Reuse existing token conventions, or create `src/theme/tokens.css`. Record the supplied colors, requested modes and density, derived roles, and contrast results there or alongside it. Preserve the user's exact brand values. Scope preferences to the project: one product's brand, light-only mode, desktop-only layout, density, avatar removal, or sidebar behavior must not become global Lemon rules.

## Build or refine

- Establish the actual screen, task, framework, direction, modes, and viewport scope. Keep existing components and behavior when handling a narrow annotation.
- Read [components-and-interactions.md](references/components-and-interactions.md) for the controls being built, especially search, select, checkbox, status tags, navigation, and loading. Inspect the matching live source when the request demands an exact match. If unavailable, use the documented baseline and name the verification limit.
- Use Lemon's documented font family, weight/size scale, radius roles, and 4px spacing scale. Do not substitute arbitrary intermediate type sizes, synthesize extra weights, or assign one large radius to every component.
- Build frosted layers with a thin light edge and restrained depth. Adjust opacity, backdrop, and contrast together; blur over a uniform opaque surface is not a visible glass treatment. Keep data readable and provide an opaque fallback.
- Prefer neutral selection and semantic status colors. A supplied brand may replace action colors when requested. Distinguish an informational status tag from a clickable filter chip; neither relies on color alone.
- Use project tokens consistently across hover, pointer-active, keyboard-focus, selected, disabled, loading, error, and success states. A gentle pointer state does not justify removing keyboard focus.
- Extend established components or framework primitives before writing custom controls. If a browser-native popup visibly breaks the requested style, use a mature accessible select or implement the full interaction contract in the component reference. CSS on a closed native select cannot guarantee its popup appearance.
- Use logical positioning for RTL. Keep codes, phones, and numeric strings LTR; localize Persian numeric display where appropriate. Mirror directional icons, not real-world objects.
- Keep maintainable source styles. Consolidate changed tokens and component rules instead of accumulating conflicting override blocks. When delivering one HTML file, embed the canonical CSS/JS and verify that embedded copies remain synchronized.

## Verify and hand off

Apply [validation.md](references/validation.md) to the changed surface, fix material defects, and report what was actually checked. Source inspection, code-level checks, browser behavior tests, and screenshot comparisons provide different evidence; do not substitute one for another. Never present stale screenshots as the current UI or an invented mock as an original Lemon sample.

Summarize the adopted theme, deliberate departures, relevant tests, and any blocked visual checks. Preserve user authorization boundaries: the skill does not authorize publishing, GitHub writes, dependency installation, or changes to unrelated projects.
