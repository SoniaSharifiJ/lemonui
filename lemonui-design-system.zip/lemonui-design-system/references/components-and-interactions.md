# Component implementation contracts

Read only sections needed for the current surface. Source-grounded facts are recorded in `lemon-reference.md`; implementation recommendations below are not official Lemon CSS recipes.

## Typography and radius integrity

Use Vazirmatn for Persian and Latin. Supported weights are 400, 600, 700; documented sizes are 7, 8, 9, 10, 12, 14, 16, 20, 24, 32, 48, 56, 64, 72px. Map product roles onto this scale, rather than using all sizes. Avoid accidental 11/13px declarations or 500/800 weights when matching Lemon. Choose readable product text, not microscopic sizes just because the scale includes them. Preserve a functional fallback if the font cannot load. The public reference does not establish exact universal line heights or letter spacing.

Documented radius roles: xs=4, sm=8, md=12, lg=24, xl=32, 2xl=64, full=9999px. Card uses lg, Input md, Tag sm, Checkbox xs. Audit final computed styles, including shorthand declarations, native control styles, inline styles, and breakpoint overrides.

## Moderate glass

Use three distinct roles: canvas, glass surface, and brighter active glass. A near-white warm or cool canvas is an optional project choice; pure white is not forbidden by Lemon. For restrained glass, use faint background variation and translucent layers, rather than saturated gradients. Keep the content area calm.

Documented blur references: regular/focus 24px, panel 48px, chip 12px, modal 40px. These are effect recipes, not a requirement to blur every row. Avoid stacking expensive blur on hundreds of cells. Separate layers with light edges and soft shadows instead of heavy colored borders. Check contrast against composited surfaces, not just nominal white.

## Search and inputs

- Match Input's glass body and radius/md, with brighter raised glass on focus. Documented heights are 32, 40, 48, 56px. Match adjacent button heights intentionally.
- Use a descriptive leading icon on the right in RTL, linked labels or accessible names, optional shortcut and clear action. Placeholder text is not the label. Use an accessible name on icon buttons.
- A clear action updates the query, visible results, and any synchronized search field, then restores focus. Hide it when empty. Do not put multiple labelable controls inside a single wrapping `label`; use a wrapper with explicitly labeled controls.
- Use a thin quiet boundary for pointer-active states if requested. Retain a visible 2px outside keyboard ring with sufficient contrast, such as `:focus-visible` or a parent `:has(input:focus-visible)`. Do not suppress focus through blanket `outline:none` rules.
- Show actionable errors with text and programmatic associations. Read-only and disabled are different states.

## Select dropdowns

Prefer an existing accessible select. If a custom popup is necessary, match the input trigger and popup glass, typography, radius, shadows, hover, and selected states. Keep current value, active option, and selected option distinct.

Interaction contract:

- Name the control, expose expanded state and listbox relationship, and expose selected options. Use a combobox pattern consistently, including active-descendant navigation when focus remains on its trigger.
- Support arrows, Home/End, Enter/Space, Escape, Tab, and typeahead appropriate to the implementation. Announce the chosen value. Disabled options must not be selectable.
- Escape dismisses the popup before an enclosing dialog; Tab does not trap focus. Outside pointer interaction closes it. Restore or preserve focus predictably.
- Position within the viewport, flip when needed, cap height, and allow internal scrolling. Use a supported top-layer mechanism or framework portal compatible with modal focus management. A popup clipped by a card or blocked behind a dialog is defective.
- Internal option scrolling must not trigger a global scroll-dismiss handler. Avoid unintended document scrolling during active-option changes. Close or reposition on actual viewport/ancestor movement.
- Synchronize programmatic updates, native changes, form reset, disabled state, required validation, submission, and change/input events. If retaining a hidden native select, avoid duplicate accessible controls and ensure labels and validation target the visible control. A visual proxy alone is insufficient for a required field.
- Clean up timers, observers, and listeners when controls are removed. Avoid accumulating handlers after rerender. Handle reopen during a closing animation without a stale callback hiding the new popup.
- Preserve native functionality when enhancement fails. Test the actual enhanced control; selecting a hidden native element does not validate popup behavior.

## Checkboxes

Lemon documents 16/20px glass boxes, radius/xs, and a dark border when checked. Prefer a native checkbox with styled appearance; retain Space, checked, disabled, and indeterminate semantics. Show both check and dash distinctly. A bulk header's indeterminate property must reflect partial selection. Keep hit areas usable without inflating the visible box. Verify forced-colors fallback and keyboard focus. Gentle styling must not erase essential control boundaries.

## Semantic labels and filter chips

Use noninteractive Tag for status, clickable Chip for filtering. Lemon defines neutral, success, warning, danger, info tones with soft/outline tags. Status text must explain the meaning without hue; the same status keeps the same tone. In RTL the tag's status dot follows the text.

Examples to adapt: `به اتمام رسیده` → success, `در حال انجام` → info, `نیازمند اقدام` → warning, `ناموفق` → danger, `تعیین نشده` → neutral. These Persian labels and exact colors are product choices. Do not translate a source status into a different business meaning to fit a palette.

Do not invent completed records just to display green. If demo fixtures are changed to illustrate states, label them as demo data and recompute every affected total, badge, filter count, export, and report. Preserve supplied real data.

## Navigation and state transitions

Use a single shared moving selection surface when that pattern is requested or already established. Keep selection semantics on the actual navigation item. The moving layer is decorative, noninteractive, and positioned relative to its container. Recalculate after sidebar collapse, font loading, resize, and content changes. Do not move keyboard focus merely to animate selection. Do not mark modal-only actions as the current page unless the product's navigation model supports that.

Suggested project timing: 120–180ms for local feedback; 200–320ms for short spatial transitions. These are recommendations, not Lemon-published timings. Animate opacity/transform where possible, avoid `transition:all`, and allow immediate repeated interaction. Keep active, hover, and focus visually distinct. With reduced motion, keep state changes and feedback while removing spatial movement and shimmer.

## Cards, tables, skeletons

Keep a card about one topic, with equal heights in a row. Table toolbar can contain search, filters, and actions on the same surface; this integration is a product decision. Preserve key columns and readable rows before expanding density. A sticky header needs a legible surface.

Skeletons should mirror the real geometry and reserve its dimensions. Mark the affected region busy, hide decorative skeletons from assistive technology, and prevent interaction with concealed controls. Do not hide the whole region containing the skeleton or allow it to steal focus. A skeleton overlay must remain aligned when the table has been scrolled.

Drive loading from actual request state. Avoid artificial delays in production; short demo delays are acceptable only for a clearly identified prototype. Prevent flashes for very fast operations and consider skeletons for initial/data-replacement loads rather than every keystroke. Keep existing data visible for background refresh when appropriate.

Clear busy/inert state on success, empty result, error, cancellation, and teardown. Cancel stale callbacks so an old request cannot dismiss a newer loader or overwrite new results. Provide empty/error/retry states. Reduced motion uses a static placeholder. Test rapid filter changes, refresh during loading, modal interactions, and shorter desktop windows. If a replay control is supplied in a prototype, label its purpose and make it accessible.
