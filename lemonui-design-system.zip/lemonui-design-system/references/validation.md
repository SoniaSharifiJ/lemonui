# Targeted quality review

Use checks proportional to the changed surface. Do not require a full app audit for a small reversible edit.

## Source and theme

- Identify the relevant original sample and mode. Keep source facts distinct from product adaptations and record access dates when source facts are updated.
- Verify actual Vazirmatn loading, 400/600/700 weights, documented sizes, and component radius roles. Inspect computed styles where possible, including shorthands and all relevant breakpoints.
- Check tokens for undefined variables, duplicate/conflicting definitions, accidental hardcoded brand values, missing states, and unsynchronized embedded copies. Do not silently generate dark mode for a light-only request.
- Measure text contrast on the actual glass composite: 4.5:1 normal text, 3:1 large text, and 3:1 where essential boundaries/focus indicators require it. Do not assume decorative white edges establish a usable control boundary.

## Interaction and structural bugs

- IDs are document-wide: namespace SVG symbol IDs separately from button/input IDs. Check all labels, ARIA references, and use/href targets.
- Test custom selects using their visible trigger/options: pointer, keyboard, active vs selected, outside dismissal, dialog Escape, viewport edges, internal scrolling, disabled/required state, programmatic change and form reset.
- Test checkbox selection and mixed bulk selection, search clear and synchronization, filters and reset, page size, pagination, row details, and create/edit only when in scope. Keep counts and actual data consistent.
- Test shared menu selection after resizing/collapse and rapid activation. Check that the marked current page reflects the displayed destination.
- Exercise skeleton success/error/empty/cancel paths and rapid repeat operations. Busy and inert state must not remain stuck. Verify static reduced-motion behavior and focus recovery.
- For transitions, confirm both entry and exit when promised, and reopening before exit finishes. Changing selection should not shift surrounding content or leave a duplicate highlighter.
- Check clipping and scroll at the requested desktop widths/heights. Give the table real working space while preserving its footer and keyboard reachability. A desktop-only brief does not justify ignoring browser zoom.

## Evidence and release

If browser access is available, capture the actual final state at a matching viewport and mode, inspect the saved screenshot, and compare it with the actual source sample. Include representative resting, focused, open-dropdown, selected, and loading states when those changed.

If access is blocked, continue authorized source edits and code-level checks; state the missing evidence. Respect the tool's access boundary. Do not render through another surface to bypass a blocked local-file observation, claim visual verification from a simulated DOM, or reuse an old screenshot as current.

Report useful outcomes: what changed, why, which checks ran, remaining limitations. A syntax check proves syntax, a DOM simulation covers only modeled behavior, and a screenshot cannot prove full keyboard or screen-reader correctness. Do not call a product fully compliant from partial checks.
