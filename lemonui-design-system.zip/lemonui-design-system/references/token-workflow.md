# Project color system workflow

This adapts Lemon's semantic color architecture to the current project; it is not a published Lemon palette-generation algorithm.

## Ask and adopt

Follow the first-use question in SKILL.md before generating the project's first UI. Accept a primary color, multiple brand colors, brand guidelines, an existing palette, theme files, design tokens, or a visual reference. Reuse information already supplied for this project. If the user has no color system, select a suitable palette and state the assumption.

Inspect existing project tokens and supplied material before deriving replacements. Preserve supplied values and role names where practical. Accept valid CSS color formats and resolve supplied token references; do not force everything into #RRGGBB. Clarify ambiguous color names or mappings only when they materially affect the result. Treat colors inferred from a visual reference as approximations and say so.

## Map and derive roles

- Reuse provided palette scales and semantic roles first. If only a brand color is supplied, preserve it as `--brand-base` (or the project's equivalent) and derive a compact tonal ramp as needed. Label derived shades as project choices, not official Lemon tokens.
- Adapt backgrounds, surfaces, text, icons, borders, focus, brand accents, states, and charts where used to the supplied system. Map light and dark modes when required by the project; derive missing mode values without overwriting supplied values silently.
- Measure contrast for actual foreground/background pairs, including translucent surfaces. Normal text should reach 4.5:1, large text 3:1, and essential control boundaries and focus indicators 3:1 against adjacent colors. Choose readable on-brand foregrounds. Where a supplied combination fails, preserve the original brand value and use an accessible derived shade for the affected UI role; explain the adjustment.
- Keep primitive colors separate from semantic roles. Use semantic tokens throughout components instead of scattering literal colors.
- Keep Lemon's neutral primary actions and brightness-based selection where compatible with the brief. The user's project color system takes precedence when it defines action or selection colors. Preserve Lemon's other relevant layout, typography, glass, and RTL guidance.
- Keep keyboard focus visible in each requested mode with a 2px outside ring. Pointer-active controls may use a lighter, thinner edge; do not confuse that edge with keyboard focus. Do not rely on hue alone for status or selection.

## Persist and reuse

Store variables in the current project's existing theme location, or `src/theme/tokens.css` if none exists. `assets/tokens.template.css` is a valid neutral light starter, not a branded theme or official palette export. Adopt the supplied brand and check its state/composite roles before use. Extend only requested modes; do not add dark CSS to a light-only deliverable.

Include the semantic roles actually needed for glass fill/active fill/edge, input hover/focus, quiet pointer boundaries, visible keyboard focus, checkbox strokes, status tones, table states, skeletons and motion. Reuse documented type/radius values and map them to product roles. Check undefined variables and competing overrides, including embedded copies in a standalone HTML export.

Record the adopted system, supplied source values, derived or adjusted roles, mode mappings, and relevant contrast results in the token file or adjacent project theme documentation. This record marks first-use setup as complete. Subsequent screens and skill calls in this project should reuse it without asking again unless the user requests a color change. Keep all project-specific choices in the project, not in the installed skill or another project's theme.

## CSS framework adapter

The core skill is framework-neutral. If a project uses Tailwind, map semantic CSS variables into its theme; otherwise use the project's native token mechanism. Do not add Tailwind solely because this reference is a design system.
