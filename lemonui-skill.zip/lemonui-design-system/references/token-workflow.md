# Project brand token workflow

This is a required workflow for the Lemon UI Skill, not a published Lemon algorithm.

## Ask and validate

Request the primary brand as `#RRGGBB` before the first screen is generated. Accept case-insensitive hex digits; normalize to uppercase. Reject shorthand, missing `#`, alpha, names, or malformed values and ask for a corrected 6-digit value.

## Derive roles

- Preserve the exact user color at `--brand-base`.
- Generate a compact tonal ramp by mixing the input with white for light tints and black for dark shades. Label derived values with numeric steps only as project palette primitives; don't claim those steps are Lemon's.
- Compute relative luminance and choose `--on-brand` from near-black or white based on contrast. The chosen foreground must achieve at least 4.5:1 for normal-sized text on `--brand-base`; if neither does, use the closest derived darker/lighter shade for text-bearing control backgrounds and retain the exact color for decorative use.
- Keep brand semantic roles separate from Lemon's neutral action/selection roles. Lemon's reference uses dark neutral primary actions and brightness-based selection; preserve these in the demo unless the product brief explicitly overrides them.
- Map both light and dark values for `bg/canvas`, `bg/surface`, `text/primary`, `text/secondary`, `border/default`, `brand/base`, `brand/strong`, `brand/subtle`, and state colors as appropriate. Never map a semantic role to a decorative HEX without checking its actual text contrast.
- Keep focus visible in both modes with a 2px outside ring. Do not rely on hue alone for status or selection.

## Persist and reuse

Store theme variables under the current project's existing theme location. For a new Vite demo, use `src/theme/tokens.css`. Include the original input, derived shades, semantic light/dark values, and contrast results in a project-readable token file or adjacent README. Keep subsequent screens on these semantic roles and do not ask again within that project unless the user asks to change the brand.

## CSS framework adapter

The core skill is framework-neutral. If a project uses Tailwind, map the semantic CSS variables into the project's Tailwind theme; if it uses another system, use its native token mechanism. Do not add Tailwind solely because this reference is a design system.
