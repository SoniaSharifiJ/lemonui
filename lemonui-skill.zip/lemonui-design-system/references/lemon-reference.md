# Lemon UI reference-grounded rules

Source inspected on 2026-10-22: https://lemonui.ir/ (Overview, Foundation, Color, Typography, Spacing & Radius, Effects, Light & Dark, Components overview, Button, Input, Card). This file records only rules visible in those public pages. Review the source before claiming newer or broader coverage.

## Identity and visual principles

- Lemon describes itself as a Persian, right-to-left design system for Figma.
- RTL is foundational: segment order, chat-bubble corners, progress direction, rating half-stars, and directional icon behavior account for RTL.
- The visual language uses translucent/frosted glass, blur, soft shadows, and a thin light edge.
- The overview says there is no accent color for selection; selection is shown through brightness. The Card page repeats that selected cards get brighter glass instead of an accent color.
- Light mode uses bright translucent surfaces and softer shadows. Dark mode uses smoked glass, depth, slightly lighter surfaces over the background, and a subtler edge.
- Lemon describes its components and foundations as variable-driven.

## Color architecture

- Color documentation separates base primitives from semantic tokens. It explicitly says to use semantic tokens so dark mode works by mapping semantic roles to different primitive values.
- The reference shows neutral, red, green, amber, and blue primitive scales; it documents semantic groups for background, text, icon, border, glass, tables, skeletons, and charts.
- Both light and dark values are shown for semantic roles. The palette itself is reference data, not a requirement to keep the same brand colors in another product.
- The component pages identify token examples such as `bg/inverse`, `glass/fill-strong`, `glass/stroke`, `glass/focus`, `border/focus`, `text/tertiary`, and `border/danger`.
- Deriving a new project's brand scale from a user-provided HEX is a project-specific operation, not a Lemon-published algorithm.

## Typography

- Family: Vazirmatn. The reference calls out Persian and Latin side by side.
- Weights: Regular 400, SemiBold 600, Bold 700.
- Documented font sizes: 7, 8, 9, 10, 12, 14, 16, 20, 24, 32, 48, 56, 64, 72 px.
- In Persian copy, use Persian digits; the page specifies `٬` for thousands and `٫` for decimals.

## Spacing, radii, and border widths

- Spacing uses a fixed shared scale, based on a 4px scale.
- Gap values documented: 0, 2, 4, 8, 12, 16, 20, 24, 28, 32, 40, 64 px.
- Padding values documented: 0, 4, 8, 12, 16, 20, 24, 28, 32, 40 px.
- Radius values documented: 0, 4, 8, 12, 24, 32, 9999 px.
- Border widths documented: 0, 1, 1.5, 2 px.
- The overview says 34 spacing/radius tokens total; do not invent missing token names from the displayed values.

## Effects and surfaces

- The Effects page documents 10 named effect styles. Relevant recipes: `glass/regular` uses 24px blur and soft shadows; `glass/focus` uses 24px blur, stronger shadow and white ring; `glass/panel` uses 48px blur; `glass/chip` uses 12px blur; `modal/elevation` uses 40px blur.
- In Light & Dark, glass fill/stroke semantic tokens map to different alpha values per mode.
- Use blur as progressive enhancement and provide a sufficiently opaque fallback so text remains legible where backdrop blur is unavailable.

## Components overview

- The public Components overview reports 49 pages, 148 components, and 3,019 variants. It describes components as built with Auto Layout, Variants, and Variables, and says each includes Focus and Error states.
- The overview groups components into Actions, Forms & Inputs, Navigation, Feedback & Status, Data Display, Overlays, and Media & Chat. Individual component pages provide anatomy, variants, usage guidelines, and accessibility details; use those pages when a requested component needs more than a basic pattern.

## Components: Button

- Primary is solid black/dark in the documented default; Secondary is glass; Tertiary is text-only with hover background; destructive actions use Danger variants.
- One Primary per section; labels should be verbs; do not use Primary for destructive actions.
- Button sizes: 32, 40, 48, 56px; these match Input heights.
- States include default, hover, pressed, loading, disabled, focus.
- Leading icon sits to the right of the label in RTL; directional icons are mirrored.
- Icon-only buttons need an accessible text label or tooltip. Focus is a 2px outside ring using the focus-border role.

## Components: Input

- Input uses glass, with four sizes matching Button: 32, 40, 48, 56px.
- Labels can be outside or inside/floating. Provide helper/error text below.
- A placeholder does not replace a label. Error messages should explain how to fix the issue and use both text and color.
- Persian text is right aligned; numbers, phone numbers, and codes remain LTR.
- Read-only is for visible values that are not editable. Focus uses a 2px outside ring.

## Components: Card

- Documented base card styles: glass, elevated, outline, filled. States include default, hover, selected, disabled, focus.
- Keep each card to one topic, keep cards in a row the same height, avoid nested cards and multiple primary actions in one card.
- If the whole card is clickable, use one main link. A selected card gets brighter glass instead of an accent color.

## What the reference does not establish

The inspected pages do not define a universal app shell, breakpoint table, chart layout, full WCAG contrast report, CSS variable names, Tailwind configuration, or a deterministic HEX-to-shade generation method. Treat these as project choices. Measure contrast for actual foreground/background pairs and document responsive decisions locally.


