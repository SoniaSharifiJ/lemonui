# Install the Lemon UI Skill

1. Extract `skill.zip`.
2. Copy its `lemonui-design-system` folder into `$CODEX_HOME/skills/` (commonly `~/.codex/skills/`).
3. Start a new Codex task with `$lemonui-design-system` and ask it to build your UI.
4. The skill requests a primary color in `#RRGGBB` format before generating the first screen for each project, then saves reusable semantic tokens in that project.

The skill does not include the demo code or project documentation; those stay in the full project folder.
