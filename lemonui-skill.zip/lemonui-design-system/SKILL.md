---
name: lemonui-design-system
description: Build cohesive RTL-first product interfaces using the public Lemon Design System's documented foundations and component guidance. Use when creating or revising UI that should follow Lemon's glass surfaces, semantic tokens, Vazirmatn typography, and RTL patterns.
---

# Lemon UI Design System

Create product UI informed by Lemon's public reference at https://lemonui.ir/. Read [lemon-reference.md](references/lemon-reference.md) for documented rules and [token-workflow.md](references/token-workflow.md) when setting up or changing project theme tokens. Use [tokens.template.css](assets/tokens.template.css) as a starting point when the project has no token file.

## Required first-use gate

Before the first UI generation in each project, ask the user for the primary brand color as a 6-digit HEX (`#RRGGBB`). Do not generate UI until they provide a valid value. If they describe a color by name only, ask for the exact HEX rather than guessing. Once provided:

1. Validate the syntax and record the user's exact input as `brand/base`.
2. Derive light and dark brand steps and on-brand foregrounds using the token workflow. Check text contrast and choose a readable foreground; do not assume white text is accessible.
3. Save project-scoped tokens at the project's existing theme-token location, or create `src/theme/tokens.css` if none exists. Preserve existing project tokens and conventions where practical.
4. Summarize the saved brand value and any derived roles. Reuse these tokens in later screens for this project without asking again unless the user requests a brand change.

## Build workflow

1. Identify the requested screen, user goal, framework, and target direction. Keep the implementation framework-agnostic unless the project already uses a framework.
2. Read only the relevant rules in the references. Treat reference-grounded rules as constraints; label undocumented choices as assumptions.
3. Use semantic tokens for surfaces, text, borders, icons, state, spacing, radii, and brand roles. Keep primitives separate from semantic roles.
4. Compose components consistently. Make one primary action obvious per section; use glass/neutral secondary controls and brightness for selection unless the product explicitly requests another behavior.
5. Implement direction-aware layout, logical CSS properties, keyboard focus, labels, error text, and responsive behavior. Keep phone numbers, codes, and numeric data LTR inside RTL layouts.
6. Before handoff, review the screen for token integrity, component consistency, spacing, type hierarchy, component states, contrast, RTL, responsive behavior, and assumptions. Fix material problems and report any checks that need a live browser or runtime.

## Scope and fidelity

Lemon is a Persian RTL-first Figma system whose public documentation provides examples and token relationships, not a framework package. Recreate only the pieces needed for the requested product screen. Do not present inferred CSS values or newly derived brand shades as official Lemon tokens. Use the source's documented values when available and retain an accessible project-specific fallback when it does not specify a value.

